const Logout = (props) => {

  return (
    <div>
    </div>
  )
}

export default Logout